DataStax Kafka Connector for Apache Cassandra

The DataStax Kafka Connector for Apache Cassandra enables users to ingest topics from Kafka to tables in Cassandra, DataStax Enterprise, or DataStax Astra. Visit the links below for all connector information.

Download: https://downloads.datastax.com/#akc
Docs: https://docs.datastax.com/en/kafka/doc
Installation: https://docs.datastax.com/en/kafka/doc/kafka/kafkaInstallLink.html
Source: https://github.com/datastax/kafka-sink
Examples: https://github.com/DataStax-Examples